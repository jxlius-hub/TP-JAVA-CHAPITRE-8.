# TP Java – Chapitre 8 : Application web, Servlet et MariaDB/MySQL

## Prérequis
- JDK 17, Maven, Apache Tomcat 10.1+ (Jakarta)
- MariaDB ou MySQL (ex. via XAMPP/WAMP)

## Étapes
1. Créer la base : `mysql -u root -p < database.sql` (ou coller le fichier dans phpMyAdmin / HeidiSQL).
2. Adapter USER / PASSWORD dans `src/main/java/tp/Database.java`.
   - Pour MySQL avec le driver MySQL : URL `jdbc:mysql://localhost:3306/tp_java` + dépendance `com.mysql:mysql-connector-j`. (Le driver MariaDB fonctionne aussi avec MySQL.)
3. Compiler : `mvn clean package` → `target/tp.war`.
4. Copier `tp.war` dans `tomcat/webapps/` puis démarrer Tomcat.
5. Ouvrir http://localhost:8080/tp/etudiants, remplir le formulaire.
6. Vérifier dans la base : `SELECT * FROM tp_java.etudiant;`

## Fonctionnement
- `doGet` : affiche le formulaire et lit la table (SELECT).
- `doPost` : reçoit le formulaire et insère (INSERT avec PreparedStatement, contre l'injection SQL), puis redirige.
