package tp;
import java.sql.*;
public class Database {
    // MariaDB : jdbc:mariadb://...  (fonctionne aussi avec MySQL)
    private static final String URL = "jdbc:mariadb://localhost:3306/tp_java";
    private static final String USER = "root";
    private static final String PASSWORD = "";
    static { try { Class.forName("org.mariadb.jdbc.Driver"); } catch (ClassNotFoundException e) { throw new RuntimeException(e); } }
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }
}
