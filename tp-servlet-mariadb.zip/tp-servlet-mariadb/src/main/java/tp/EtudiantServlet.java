package tp;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.*;
import java.sql.*;

@WebServlet("/etudiants")
public class EtudiantServlet extends HttpServlet {

    // GET : affiche le formulaire + la liste lue dans la base
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        resp.setContentType("text/html;charset=UTF-8");
        PrintWriter out = resp.getWriter();
        out.println("<html><head><meta charset='UTF-8'><title>TP Servlet</title></head><body>");
        out.println("<h1>Enregistrer un étudiant</h1>");
        out.println("<form method='post' action='etudiants'>");
        out.println("Nom : <input name='nom' required><br>Prénom : <input name='prenom' required><br>");
        out.println("Email : <input type='email' name='email' required><br><button>Enregistrer</button></form>");
        out.println("<h2>Données dans la base</h2><table border='1'><tr><th>ID</th><th>Nom</th><th>Prénom</th><th>Email</th></tr>");
        try (Connection c = Database.getConnection();
             Statement st = c.createStatement();
             ResultSet rs = st.executeQuery("SELECT id, nom, prenom, email FROM etudiant ORDER BY id DESC")) {
            while (rs.next()) {
                out.printf("<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td></tr>%n",
                    rs.getInt("id"), esc(rs.getString("nom")), esc(rs.getString("prenom")), esc(rs.getString("email")));
            }
        } catch (SQLException e) {
            out.println("<tr><td colspan='4'>Erreur : " + esc(e.getMessage()) + "</td></tr>");
        }
        out.println("</table></body></html>");
    }

    // POST : insère les données du formulaire dans la base
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException, ServletException {
        req.setCharacterEncoding("UTF-8");
        String sql = "INSERT INTO etudiant (nom, prenom, email) VALUES (?, ?, ?)";
        try (Connection c = Database.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, req.getParameter("nom"));
            ps.setString(2, req.getParameter("prenom"));
            ps.setString(3, req.getParameter("email"));
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new ServletException(e);
        }
        resp.sendRedirect("etudiants"); // Post/Redirect/Get
    }

    private static String esc(String s) {
        return s == null ? "" : s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;");
    }
}
